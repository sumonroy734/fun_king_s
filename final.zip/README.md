# Lock Screen

A Pen created on CodePen.

Original URL: [https://codepen.io/khadkamhn/pen/EVaJLy](https://codepen.io/khadkamhn/pen/EVaJLy).

Lock screen is based on HTML, jQuery and CSS that simulate hybrid app design.

Credits:
---------------
<ul>
<li>Nice toggle using  <a href="http://jquery.com" target="_blank">jQuery</a></li>
<li>Beautiful icons from <a href="http://ionicons.com/" target="_blank">ionicons</a></li>
<li>Awesome animate from <a href="https://daneden.github.io/animate.css/" target="_blank">Animate.css</a></li>
<li>Pattern lock pLugin from <a href="http://github.com/s-yadav/patternLock" target="_blank">Pattern Lock</a></li>
<li>Background image from <a href="http://unsplash.com/" target="_blank">Unsplash</a></li>
<li>Google font available at <a href="http://www.google.com/fonts/specimen/Roboto" target="_blank">Roboto</a></li>
</ul>

<em>I'm glad for using these resources and expecting same as time ahead</em>